/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import com.luciad.lucy.ILcyLucyEnv;
import com.luciad.lucy.eclipse.core.*;
import com.luciad.lucy.eclipse.util.EventQueueUtil;
import com.luciad.lucy.gui.*;

import org.eclipse.ui.*;

public class LucyPerspectiveFactory implements IPerspectiveFactory {
  private static final String ID_PREFIX = "com.luciad.lucy.eclipse.perspective.folder.";

  public void createInitialLayout( IPageLayout layout ) {
    String editorArea = layout.getEditorArea();
    layout.setEditorAreaVisible( false );
    // layout.setFixed(true);


    IFolderLayout mapFolder = layout.createFolder( ID_PREFIX + "map", IPageLayout.RIGHT, 0.2f, editorArea );
    mapFolder.addPlaceholder( LucyViewPart.VIEW_ID + ":" + ApplicationPaneFactory.MAP_PANE_ID + "*" );


    IFolderLayout horizontalFolder = layout.createFolder( ID_PREFIX + "horizontal", IPageLayout.BOTTOM, 0.6f, ID_PREFIX + "map" );
    horizontalFolder.addPlaceholder( LucyViewPart.VIEW_ID + ":" + ApplicationPaneFactory.HORIZONTAL_PANE_ID + "*" );


    IFolderLayout verticalFolder = layout.createFolder( ID_PREFIX + "vertical", IPageLayout.TOP, 0.4f, editorArea );
    verticalFolder.addPlaceholder( LucyViewPart.VIEW_ID + ":" + ApplicationPaneFactory.VERTICAL_PANE_ID + "*" );

    IFolderLayout verticalFolder2 = layout.createFolder( ID_PREFIX + "vertical2", IPageLayout.BOTTOM, 0.6f, editorArea );
    verticalFolder2.addPlaceholder( LucyViewPart.VIEW_ID + ":" + ApplicationPaneFactory.VERTICAL_PANE_2_ID + "*" );
    

    final List mapIds= new ArrayList();
    final List horizIds= new ArrayList();
    final List vertIds= new ArrayList();
    final List vert2Ids= new ArrayList();
    
    //the application panes must be constructed on the AWT event dispatch thread, but the wiring between
    //the application panes and the Eclipse views must happen on this thread.
    EventQueueUtil.invokeAndWait(new Runnable(){
      @Override public void run() {
          // getting the manager starts lucy.
          ILcyLucyEnv lucyEnv = LucyEnvManager.getManager().getLucyEnv();
          TLcyApplicationPaneManager paneManager = lucyEnv.getUserInterfaceManager().getApplicationPaneManager();

          for ( int i = 0; i < paneManager.getApplicationPaneCount(); i++ ) {
            ILcyApplicationPane p = paneManager.getApplicationPane( i );
            if ( p.isAppVisible() && getSecondaryID( p ).startsWith( ApplicationPaneFactory.MAP_PANE_ID ) ) {
              String id = LucyViewPart.VIEW_ID + ":" + getSecondaryID( p );
              mapIds.add(id);
            }
          }

          for ( int i = 0; i < paneManager.getApplicationPaneCount(); i++ ) {
            ILcyApplicationPane p = paneManager.getApplicationPane( i );
            if ( p.isAppVisible() && getSecondaryID( p ).startsWith( ApplicationPaneFactory.HORIZONTAL_PANE_ID ) ) {
              String id = LucyViewPart.VIEW_ID + ":" + getSecondaryID( p );
              horizIds.add(id);
            }
          }

          for ( int i = 0; i < paneManager.getApplicationPaneCount(); i++ ) {
            ILcyApplicationPane p = paneManager.getApplicationPane( i );
            if ( p.isAppVisible() && getSecondaryID( p ).startsWith( ApplicationPaneFactory.VERTICAL_PANE_ID ) ) {
              String id = LucyViewPart.VIEW_ID + ":" + getSecondaryID( p );
              vertIds.add(id);
            }
          }

          for ( int i = 0; i < paneManager.getApplicationPaneCount(); i++ ) {
            ILcyApplicationPane p = paneManager.getApplicationPane( i );
            if ( p.isAppVisible() && getSecondaryID( p ).startsWith( ApplicationPaneFactory.VERTICAL_PANE_2_ID ) ) {
              String id = LucyViewPart.VIEW_ID + ":" + getSecondaryID( p );
              vert2Ids.add(id);
            }
          }
      }
    });

    for (Iterator it = mapIds.iterator(); it.hasNext();) {
      String id = (String) it.next();
      mapFolder.addView( id );
    }
      for (Iterator it = horizIds.iterator(); it.hasNext();) {
      String id = (String) it.next();
      horizontalFolder.addView(id);
    }
      for (Iterator it = vertIds.iterator(); it.hasNext();) {
      String id = (String) it.next();
      verticalFolder.addView(id);
    }
      for (Iterator it = vert2Ids.iterator(); it.hasNext();) {
      String id = (String) it.next();
      verticalFolder2.addView(id);
    }
  }

private String getSecondaryID( ILcyApplicationPane aApplicationPane ) {
    return LucyEnvManager.getManager().getApplicationPaneFactory().getSecondaryID( aApplicationPane );
  }
}
