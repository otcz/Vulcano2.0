/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.lucy.*;
import com.luciad.lucy.eclipse.util.EventQueueUtil;
import com.luciad.lucy.util.TLcyVetoException;
import com.luciad.lucy.workspace.TLcyWorkspaceAbortedException;
import org.eclipse.core.runtime.*;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.*;

import java.awt.*;
import java.io.*;

/**
 * This class bundles all functionality to save the Lucy workspace in a file in the Eclipse
 * workspace.
 */
class WorkspaceSaver {

  private static final String WORKSPACE_FILE = "workspace.lws";

  /**
   * Adds a listener to the Eclipse workbench that will save the Lucy workspace in a file in
   * the Eclipse workspace when the workspace is about to shut down.
   */
  public static void initializeWorkspaceSaving() {
    PlatformUI.getWorkbench().addWorkbenchListener( new IWorkbenchListener() {
      
      //fields guared by implicit lock
      private boolean fWorkspaceSaveCanceled = false;
      
      private synchronized void setWorkspaceSaveCanceled( boolean aWorkspaceSaveCanceled ) {
        fWorkspaceSaveCanceled = aWorkspaceSaveCanceled;
      }

      private synchronized boolean isWorkspaceSaveCanceled() {
        return fWorkspaceSaveCanceled;
      }

      public void postShutdown( IWorkbench workbench ) {
        // not interested
      }

      public boolean preShutdown( IWorkbench workbench, boolean forced ) {
        setWorkspaceSaveCanceled( false );
        LucyPlugin.log( IStatus.INFO, "Saving workspace information" );
        
        EventQueueUtil.invokeAndWait( new Runnable() {
          public void run() {
            boolean canceled = saveLucyWorkspace();
            setWorkspaceSaveCanceled( canceled );
          }
        } );

        return !isWorkspaceSaveCanceled();
      }
    } );
  }

  private static boolean saveLucyWorkspace() {
    ILcyLucyEnv lucyEnv = LucyEnvManager.getManager().getLucyEnv();

    final IPath stateLocation = Platform.getStateLocation( LucyPlugin.getDefault().getBundle() );
    File workspace_file = stateLocation.append( WORKSPACE_FILE ).toFile();
    File dest_file = workspace_file;

    File backup_file = null;
    if ( dest_file.exists() ) {
      // Move current file to backup file
      backup_file = new File( dest_file.getParentFile(), dest_file.getName() + "~" );
      if ( backup_file.exists() ) {
        backup_file.delete();
      }
      boolean succeeded = dest_file.renameTo( backup_file );
      if ( !succeeded ) {
        backup_file = null;
      }
    }

    try {
      lucyEnv.getWorkspaceManager().encodeWorkspace( workspace_file.getAbsolutePath() );
      if ( backup_file != null ) {
        backup_file.delete();
      }
    } catch ( IOException e ) {
      LucyPlugin.log( IStatus.ERROR, "The workspace could not be saved: " + e.getMessage(), e );

      // restore the workspace file from the backed up file.
      boolean deleted = workspace_file.delete();
      if ( deleted ) {
        if ( backup_file != null ) {
          backup_file.renameTo( dest_file );
        }
      }

      if ( e instanceof TLcyWorkspaceAbortedException ) {
        return true;
      }
    }
    return false;
  }

  /**
   * Restores the Lucy workspace from the file previously saved in the Eclipse workspace.
   *
   * @param aManager The LucyEnvManager whose Lucy backend should be restored.
   */
  public static void restoreWorkspace( LucyEnvManager aManager ) {
    LucyPlugin.log( IStatus.INFO, "Restoring workspace" );

    ILcyLucyEnv lucyEnv = aManager.getLucyEnv();

    if ( lucyEnv.getLucyEnvState() != ILcyLucyEnv.STATE_INITIALIZED ) {
      lucyEnv.addLucyEnvListener( new ILcyLucyEnvListener() {
        public void lucyEnvStatusChanged( TLcyLucyEnvEvent event ) throws TLcyVetoException {
          if ( event.getID() == ILcyLucyEnv.STATE_INITIALIZED ) {
            loadStartupWorkspace( event.getLucyEnv() );
          }
        }
      } );
    }
    else {
      loadStartupWorkspace( lucyEnv );
    }
  }

  private static void loadStartupWorkspace( ILcyLucyEnv lucyEnv ) {
    String workspace_source;
    File workspace_file = Platform.getStateLocation( LucyPlugin.getDefault().getBundle() ).append( WORKSPACE_FILE ).toFile();
    if ( workspace_file.exists() ) {
      workspace_source = workspace_file.getAbsolutePath();
      try {
        lucyEnv.getWorkspaceManager().decodeWorkspace( workspace_source );
      } catch ( IOException e ) {
        LucyPlugin.log( IStatus.ERROR, "The workspace could not be loaded: " + e.getMessage(), e );
      }
    }
  }
}
