/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import com.luciad.lucy.eclipse.core.*;
import org.eclipse.jface.action.*;
import org.eclipse.ui.actions.CompoundContributionItem;

/**
 * This dynamic menu is registered in the plugin.xml. It shows the actions of the main Lucy menu
 * in the Eclipse workbench. To do this it retrieves the actions of the main menu each time it is
 * shown.
 */
public class DynamicLucyMenu extends CompoundContributionItem {

  public DynamicLucyMenu() {
  }

  public DynamicLucyMenu( String aId ) {
    super( aId );
  }

  protected IContributionItem[] getContributionItems() {
    // Start Lucy so the main menu of Lucy is populated
    LucyEnvManager.getManager();
    
    final MenuManager submenu = new MenuManager( "Lucy" );
    // a menu needs at least one contribution to be visible in the Eclipse workbench.
    Action action = createEmptyAction();
    submenu.add( action );

    submenu.addMenuListener( new IMenuListener() {
      public void menuAboutToShow( IMenuManager aManager ) {
        aManager.removeAll();
        MenuBar.getDefault().addAllActions( aManager );
        if ( aManager.isEmpty() ) {
          aManager.add( createEmptyAction() );
        }
      }
    } );

    return new IContributionItem[] { submenu };
  }

  //creates a dummy Eclipse action
  private Action createEmptyAction() {
    Action action = new Action() {};
    action.setEnabled( false );
    action.setText( "Lucy was not loaded" );
    return action;
  }
}
