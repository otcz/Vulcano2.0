/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import com.luciad.gui.ILcdAction;
import com.luciad.gui.swing.TLcdSWAction;
import org.eclipse.jface.resource.ImageDescriptor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * This adapter wraps a Lucy action and presents it as an Eclipse action. It makes sure
 * all operations on the Lucy action are performed on the correct thread.
 * 
 * @see LucyActiveSettableAdapter
 */
public class LucyActionAdapter extends org.eclipse.jface.action.Action {

  private final Action     fAction;
  private final ILcdAction fOriginalAction;

  public LucyActionAdapter( ILcdAction aAction ) {
    super( ( String ) aAction.getValue( ILcdAction.NAME ) );
    fAction = new TLcdSWAction( aAction );
    fOriginalAction = aAction;

    setEnabled( fAction.isEnabled() );
    setToolTipText( ( String ) fAction.getValue( Action.SHORT_DESCRIPTION ) );
    setDescription( ( String ) fAction.getValue( Action.LONG_DESCRIPTION ) );
    Icon icon = ( Icon ) fAction.getValue( Action.SMALL_ICON );
    if ( icon != null ) {
      setImageDescriptor( ImageDescriptor.createFromImageData( ActionMediator.convertIconToImage( icon ) ) );
    }

    fAction.addPropertyChangeListener( new ActionMediator( this ) );
  }

  public ILcdAction getAction() {
    return fOriginalAction;
  }

  public void run() {
    Runnable runnable = new Runnable() {
      public void run() {
        fAction.actionPerformed( new ActionEvent( LucyActionAdapter.this, ActionEvent.ACTION_PERFORMED, "actionPerformed" ) );
      }
    };
    EventQueue.invokeLater( runnable );
  }
}
