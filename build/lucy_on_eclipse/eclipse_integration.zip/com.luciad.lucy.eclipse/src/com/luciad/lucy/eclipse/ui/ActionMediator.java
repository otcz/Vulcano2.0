/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.Icon;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;

import com.luciad.lucy.eclipse.util.EventQueueUtil;

/**
 * This mediator keeps the state (name, icon, tooltip, ...) of the Lucy action to which it is
 * attached in sync with the specified Eclipse action.
 */
public class ActionMediator implements PropertyChangeListener {

  private final ActionFacade fAction;

  public ActionMediator( IAction aAction ) {
    fAction = new ActionFacade( aAction );
  }

  public void propertyChange( PropertyChangeEvent aEvt ) {
    if ( "enabled".equals( aEvt.getPropertyName() ) ) {
      Boolean new_val = ( Boolean ) aEvt.getNewValue();
      fAction.setEnabled( new_val.booleanValue() );
    }
    else if ( Action.NAME.equals( aEvt.getPropertyName() ) ) {
      String new_name = ( String ) aEvt.getNewValue();
      fAction.setText( new_name );
    }
    else if ( Action.SHORT_DESCRIPTION.equals( aEvt.getPropertyName() ) ) {
      String new_val = ( String ) aEvt.getNewValue();
      fAction.setToolTipText( new_val );
    }
    else if ( Action.LONG_DESCRIPTION.equals( aEvt.getPropertyName() ) ) {
      String new_description = ( String ) aEvt.getNewValue();
      fAction.setDescription( new_description );
    }
    else if ( Action.SMALL_ICON.equals( aEvt.getPropertyName() ) ) {
      Icon icon = ( Icon ) aEvt.getNewValue();
      if ( icon != null ) {
        fAction.setImageDescriptor( ImageDescriptor.createFromImageData( convertIconToImage( icon ) ) );
      }
      else {
        fAction.setImageDescriptor( null );
      }
    }
  }

  static ImageData convertIconToImage( Icon aIcon ) {
    BufferedImage bufferedImage = new BufferedImage( aIcon.getIconWidth(), aIcon.getIconHeight(), BufferedImage.TYPE_INT_ARGB );

    Graphics g = bufferedImage.getGraphics();
    g.setColor( new Color( 255, 255, 255, 255 ) );
    g.fillRect( 0, 0, bufferedImage.getWidth(), bufferedImage.getHeight() );
    aIcon.paintIcon( null, g, 0, 0 );
    g.dispose();

    return getImageData( bufferedImage );
  }

  static ImageData getImageData( BufferedImage bufferedImage ) {
    int width = bufferedImage.getWidth(), height = bufferedImage.getHeight();
    int[] data = ( ( DataBufferInt ) bufferedImage.getData().getDataBuffer() ).getData();
    ImageData imageData = new ImageData( width, height, 24, new PaletteData( 0xFF0000, 0x00FF00, 0x0000FF ) );
    imageData.setPixels( 0, 0, data.length, data, 0 );
    return imageData;
  }

  /**
   * This facade makes sure that all operations on the given Eclipse action are performed on the
   * correct thread.
   */
  private static class ActionFacade {
    private final IAction fAction;

    public ActionFacade( IAction aAction ) {
      fAction = aAction;
    }

    public void setDescription( final String aText ) {
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          fAction.setDescription( aText );
        }
      } );
    }

    public void setEnabled( final boolean aEnabled ) {
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          fAction.setEnabled( aEnabled );
        }
      } );
    }

    public void setImageDescriptor( final ImageDescriptor aNewImage ) {
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          fAction.setImageDescriptor( aNewImage );
        }
      } );
    }

    public void setText( final String aText ) {
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          fAction.setText( aText );
        }
      } );
    }

    public void setToolTipText( final String aToolTipText ) {
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          fAction.setToolTipText( aToolTipText );
        }
      } );
    }
  }
}
