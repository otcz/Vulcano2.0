/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */


package com.luciad.lucy.eclipse.core;

import com.luciad.lucy.eclipse.util.EventQueueUtil;
import com.luciad.lucy.eclipse.util.PartAdapter2;
import com.luciad.lucy.map.*;
import com.luciad.view.*;

import org.eclipse.ui.*;

import javax.swing.*;
import java.awt.*;

class ActiveMapMediator extends PartAdapter2 {
  private final IViewPart      fLucyView;
  private final Component      fApplicationPane;
  private final TLcyCombinedMapManager fMapManager;

  public ActiveMapMediator( IViewPart aLucyView, Component aApplicationPane, TLcyCombinedMapManager aMapManager ) {
    fLucyView = aLucyView;
    fApplicationPane = aApplicationPane;
    fMapManager = aMapManager;
    
    tryUpdatingActiveMap();
  }

  public void partActivated( IWorkbenchPartReference aPartRef ) {
    if ( aPartRef.getPart( false ) != fLucyView ) {
      return;
    }

    EventQueueUtil.invokeAndWait( new Runnable() {
      public void run() {
        tryUpdatingActiveMap();
      }
    
    } );
  }

  private void tryUpdatingActiveMap() {
    ILcyGenericMapComponent<? extends ILcdView, ? extends ILcdLayer> map = findMapComponent( fMapManager );
    if ( map != null ) {
      fMapManager.setActiveMapComponent( map );
    }
  }

  private ILcyGenericMapComponent<? extends ILcdView, ? extends ILcdLayer> findMapComponent( TLcyCombinedMapManager aMapManager ) {
    for (ILcyGenericMapComponent<? extends ILcdView, ? extends ILcdLayer> map : aMapManager.getMapComponents()) {
      if (SwingUtilities.isDescendingFrom(map.getComponent(), fApplicationPane)){
        return map;
      }
    }
    return null;
  }

  public static void install( IWorkbenchPage aPage, TLcyCombinedMapManager aMapManager, IViewPart aViewPart, Component aApplicationContentPane ) {
    ActiveMapMediator mediator = new ActiveMapMediator( aViewPart, aApplicationContentPane, aMapManager );
    aPage.addPartListener( mediator );
  }
}
