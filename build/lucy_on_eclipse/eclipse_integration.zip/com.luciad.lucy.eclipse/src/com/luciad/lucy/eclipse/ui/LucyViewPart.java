/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import com.luciad.gui.*;
import com.luciad.lucy.eclipse.core.LucyEnvManager;
import com.luciad.lucy.eclipse.util.EventQueueUtil;
import com.luciad.lucy.gui.ILcyApplicationPane;
import com.luciad.util.*;
import org.eclipse.albireo.core.SwingControl;
import org.eclipse.jface.action.Action;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.*;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.part.ViewPart;

import javax.swing.*;
import java.awt.*;
import java.text.MessageFormat;

/**
 * This is a view from eclipse and corresponds to an {@link ILcyApplicationPane}. The 
 * application pane will be installed in this view by the ApplicationPaneViewMediator. The
 * same mediator will also make sure that when this view is closed, the application pane is 
 * disposed as well.
 * 
 * @see com.luciad.lucy.eclipse.core.ApplicationPaneViewMediator
 */
public class LucyViewPart extends ViewPart {

  private static final String INITIAL_MESSAGE = "<html><body>Lucy version {0}<br><br>" +
  		"Use the 'Lucy' Menu to open a map or other application pane of Lucy.</body></html>";

  public static final String VIEW_ID         = "com.luciad.lucy.eclipse.LucyApplicationPaneView";

  private JPanel             fContentPanel; //confined to AWT Thread
  private Component          fAddedComponent = null; // confined to AWT thread

  private SwingControl       fSwingControl;

  public void createPartControl( final Composite parent ) {
    parent.setLayout( new FillLayout() );

    fSwingControl = new SwingControl( parent, SWT.NONE ) {
      protected JComponent createSwingComponent() {

        //create the content panel into which the application pane will be inserted.
        JPanel panel = new JPanel();
        panel.setLayout( new BorderLayout() );
        
        //if the application pane was already added to this view, insert it in the 
        //content panel immediately
        if ( fAddedComponent != null ) {
          SwingUtilities.updateComponentTreeUI( fAddedComponent );
          panel.add( fAddedComponent, BorderLayout.CENTER );
        }
        //otherwise insert a place holder that will be replaced when addToAWTContentPanel
        //is called.
        else {
          panel.add( createInitialComponent(), BorderLayout.CENTER );
        }

        fContentPanel = panel;

        LucyEnvManager.getManager().getLucyEnv().addTopLevelComponent( panel );

        return panel;
      }

      public Composite getLayoutAncestor() {
        return parent;
      }
    };

    //integrate the undo/redo functionality of Lucy with the Eclipse workbench
    IActionBars actionBars = getViewSite().getActionBars();
    actionBars.setGlobalActionHandler( ActionFactory.UNDO.getId(), new UndoAction() );
    actionBars.setGlobalActionHandler( ActionFactory.REDO.getId(), new RedoAction() );
    
    //integrate the copy/paste functionality of Lucy with the Eclipse workbench.
    actionBars.setGlobalActionHandler( ActionFactory.COPY.getId(), new LucyActionAdapter( TransferAction.createCopyAction()) );
    actionBars.setGlobalActionHandler( ActionFactory.PASTE.getId(), new LucyActionAdapter( TransferAction.createPasteAction() ) );
    actionBars.setGlobalActionHandler( ActionFactory.CUT.getId(), new LucyActionAdapter( TransferAction.createCutAction() ) );
  }

  /**
   * Adds the specified component as the only AWT component in the Eclipse view.
   * @param aComponent The AWT component to show in this Eclipse view.
   */
  public void addToAWTContentPanel( Component aComponent ) {
    assert EventQueue.isDispatchThread();
    fAddedComponent = aComponent;
    SwingUtilities.updateComponentTreeUI( fAddedComponent );
    
    if ( fContentPanel != null ) {
      fContentPanel.removeAll();
      fContentPanel.add( fAddedComponent, BorderLayout.CENTER );
      SwingUtilities.updateComponentTreeUI( fContentPanel );
      fContentPanel.invalidate();
      fContentPanel.revalidate();
    }
  }
  
  public void setApplicationPaneTitle(String aTitle){
    setPartName( aTitle );
  }

  /**
   * Sets the focus on this ViewPart.
   */
  public void setFocus() {
    fSwingControl.setFocus();
  }

  public void dispose() {
    super.dispose();
  }

  public void saveState( IMemento memento ) {
    // we have nothing to save, it is saved in the Lucy workspace.
    super.saveState( memento );
  }
  
  private static JComponent createInitialComponent() {
    return new JLabel( MessageFormat.format( INITIAL_MESSAGE, new Object[] { TLcdCopyright.getVersionNumber() } ), JLabel.CENTER );
  }

  private static class RedoAction extends Action {
    public RedoAction() {
      final TLcdUndoManager undoManager = LucyEnvManager.getManager().getLucyEnv().getUndoManager();
      undoManager.addChangeListener( new ILcdChangeListener() {
        public void stateChanged( TLcdChangeEvent aArg0 ) {
          updateFromManager( undoManager );
        }
      } );
      updateFromManager( undoManager );
    }

    public void run() {
      EventQueue.invokeLater( new Runnable() {
        public void run() {
          LucyEnvManager.getManager().getLucyEnv().getUndoManager().redo();
        }
      } );
    }

    private void updateFromManager( final TLcdUndoManager undoManager ) {
      final ILcdUndoable undoable = undoManager.getCurrentRedo();
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          if ( undoable == null ) {
            setText( "Redo" );
            setEnabled( false );
          }
          else {
            setText( undoable.getRedoDisplayName() );
            setEnabled( true );
          }
        }
      } );
    }
  }

  private static class UndoAction extends Action {
    public UndoAction() {
      final TLcdUndoManager undoManager = LucyEnvManager.getManager().getLucyEnv().getUndoManager();
      undoManager.addChangeListener( new ILcdChangeListener() {
        public void stateChanged( TLcdChangeEvent aArg0 ) {
          updateFromManager( undoManager );
        }
      } );
      updateFromManager( undoManager );
    }

    public void run() {
      EventQueue.invokeLater( new Runnable() {
        public void run() {
          LucyEnvManager.getManager().getLucyEnv().getUndoManager().undo();
        }
      } );
    }

    private void updateFromManager( final TLcdUndoManager undoManager ) {
      final ILcdUndoable undoable = undoManager.getCurrentUndo();
      EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
        public void run() {
          if ( undoable == null ) {
            setText( "Undo" );
            setEnabled( false );
          }
          else {
            setText( undoable.getUndoDisplayName() );
            setEnabled( true );
          }
        }
      } );
    }
  }
}
