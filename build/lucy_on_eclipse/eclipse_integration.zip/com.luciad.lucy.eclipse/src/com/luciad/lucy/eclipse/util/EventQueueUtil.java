/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.util;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;

import java.awt.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class EventQueueUtil {


  private static final Object sLock = new Object();

  public static void onSWT( final EventQueueRunnable aSWTRunnable, final EventQueueRunnable aAWTCallBack ) {
    asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        final Object result;
        synchronized ( sLock ) {
          result = aSWTRunnable.run( null );
        }

        if ( aAWTCallBack != null ) {
          EventQueue.invokeLater( new Runnable() {
            public void run() {
              aAWTCallBack.run( result );
            }
          } );
        }
      }
    } );
  }

  public static Display getWorkbenchDisplay() {
    return PlatformUI.getWorkbench().getDisplay();
  }

  public static void asyncExecOrNoopWhenDisposed( Runnable aRunnable ) {
    try {
      getWorkbenchDisplay().asyncExec( aRunnable );
    } catch ( SWTException e ) {
      // ignore exceptions about disposed devices and simply skip running the runnable in that case.

      // Catch the exception rather than performing a check for getWorkbenchDisplay().isDisposed(),
      // because between checking that flag and scheduling the actual runnable, some other thread may dispose
      // the display already.
      if ( e.code == SWT.ERROR_DEVICE_DISPOSED ) {
        return;
      }
      throw e;
    }
  }

  public static abstract class EventQueueRunnable {
    public abstract Object run( Object aArg );
  }

  /**
   * Invoke the runnable on the AWT event dispatch thread, and wait until it has completed.
   * 
   * Use this method instead of EventQueue.invokeAndWait, as that method is prone to deadlock
   * with the SWT event dispatching mechanisms.
   * 
   * @param runnable The Runnable to execute on the AWT event dispatch thread. Should not be null.
   */
  public static void invokeAndWait(final Runnable runnable) {    
    final AtomicBoolean complete = new AtomicBoolean(false);
    final Display display = getWorkbenchDisplay();
    EventQueue.invokeLater(new Runnable(){
      @Override
      public void run() {
        runnable.run();
        complete.set(true);
        display.wake();
      }
    });
    while(!complete.get()){
      if ( !display.readAndDispatch() ) {
        display.sleep();
      }
    }
  }
}
