/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.gui.ILcdAction;
import com.luciad.lucy.eclipse.ui.*;
import com.luciad.lucy.gui.*;
import org.eclipse.jface.action.*;

import javax.swing.event.EventListenerList;
import java.awt.*;
import java.util.*;

public class MenuBar implements ILcyMenuBar {

  private static MenuBar sDefault;

  private final Object        fLock                 = new Object();

  // all fields guarded by fLock
  private EventListenerList   fActionBarListeners   = new EventListenerList();
  private ArrayList           fActionBarItems       = new ArrayList();
  private Hashtable           fGroupDescriptors     = new Hashtable();
  private Hashtable           fMenuGroupDescriptors = new Hashtable();
  private Hashtable           fMenus                = new Hashtable();
  private Hashtable           fHelpIDs              = new Hashtable();
  private Hashtable           fDeactivatePossible   = new Hashtable();
  private Hashtable           fActionID             = new Hashtable();

  private MenuBar() {
  }

  /**
   * Returns the menubar that should be used as the main menu bar of the Lucy application.
   *
   * @return The main menu bar of the Lucy application.
   */
  public static MenuBar getDefault() {
    //Lazily load the menu bar. 
    if ( sDefault == null ) {
      sDefault = new MenuBar();
    }
    return sDefault;
  }

  public void addActionBarListener( ILcyActionBarListener aActionBarListener ) {
    synchronized ( fLock ) {
      fActionBarListeners.add( ILcyActionBarListener.class, aActionBarListener );
    }
  }

  public Object getActionBarItem( int aIndex ) {
    synchronized ( fLock ) {
      return fActionBarItems.get( aIndex );
    }
  }

  public int getActionBarItemCount() {
    synchronized ( fLock ) {
      return fActionBarItems.size();
    }
  }

  /**
   * This method cannot be used.
   */
  public Component getComponent() {
    return null; //This menu bar is not supposed to be shown as an AWT component
  }

  public void insertAction( ILcdAction aAction, TLcyGroupDescriptor aGroupDescriptor ) {
    insertAction( aAction, aGroupDescriptor, null, null );
  }

  public void insertAction( ILcdAction aAction, TLcyGroupDescriptor aGroupDescriptor, String[] aMenus, TLcyGroupDescriptor[] aMenuGroupDescriptors ) {

    synchronized ( fLock ) {
      fActionBarItems.add( aAction );
      if ( aGroupDescriptor != null ) {
        fGroupDescriptors.put( aAction, aGroupDescriptor );
      }
      if ( aMenuGroupDescriptors != null ) {
        fMenuGroupDescriptors.put( aAction, aMenuGroupDescriptors );
      }
      if ( aMenus != null ) {
        fMenus.put( aAction, aMenus );
      }
      LucyActionAdapter action = new LucyActionAdapter( aAction );
      fActionID.put( aAction, action );

      fireActionAdded( aAction );
    }
  }

  public void insertActiveSettable( ILcyActiveSettable aActiveSettable, TLcyGroupDescriptor aGroupDescriptor ) {
    insertActiveSettable( aActiveSettable, aGroupDescriptor, null, null );
  }

  public void insertActiveSettable( ILcyActiveSettable aActiveSettable, TLcyGroupDescriptor aGroupDescriptor, String[] aMenus, TLcyGroupDescriptor[] aMenuGroupDescriptors ) {
    insertActiveSettable( aActiveSettable, aGroupDescriptor, aMenus, aMenuGroupDescriptors, true );
  }

  public void insertActiveSettable( ILcyActiveSettable aActiveSettable, TLcyGroupDescriptor aGroupDescriptor, String[] aMenus, TLcyGroupDescriptor[] aMenuGroupDescriptors, boolean aDeactivatePossible ) {
    synchronized ( fLock ) {
      fActionBarItems.add( aActiveSettable );
      if ( aGroupDescriptor != null ) fGroupDescriptors.put( aActiveSettable, aGroupDescriptor );
      if ( aMenuGroupDescriptors != null ) fMenuGroupDescriptors.put( aActiveSettable, aMenuGroupDescriptors );
      if ( aMenus != null ) fMenus.put( aActiveSettable, aMenus );
      fDeactivatePossible.put( aActiveSettable, Boolean.valueOf( aDeactivatePossible ) );
      LucyActiveSettableAdapter activeSettable = new LucyActiveSettableAdapter( aActiveSettable, null );
      fActionID.put( aActiveSettable, activeSettable );

      fireActiveSettableAdded( aActiveSettable );
    }
  }

  public void removeAction( ILcdAction aAction ) {
    synchronized ( fLock ) {
      fActionBarItems.remove( aAction );
      fMenuGroupDescriptors.remove( aAction );
      fMenus.remove( aAction );
      fHelpIDs.remove( aAction );
      fGroupDescriptors.remove( aAction );
      fActionID.remove( aAction );
      fireActionRemoved( aAction );
    }
  }

  public void removeActionBarListener( ILcyActionBarListener aListener ) {
    synchronized ( fLock ) {
      fActionBarListeners.remove( ILcyActionBarListener.class, aListener );
    }
  }

  public void removeActiveSettable( ILcyActiveSettable aActiveSettable ) {
    synchronized ( fLock ) {
      fActionBarItems.remove( aActiveSettable );
      fMenuGroupDescriptors.remove( aActiveSettable );
      fMenus.remove( aActiveSettable );
      fHelpIDs.remove( aActiveSettable );
      fGroupDescriptors.remove( aActiveSettable );
      fDeactivatePossible.remove( aActiveSettable );
      fireActiveSettableRemoved( aActiveSettable );
    }
  }

  public boolean retrieveDeactivatePossible( ILcyActiveSettable aActiveSettable ) {
    synchronized ( fLock ) {
      Boolean result = ( Boolean ) fDeactivatePossible.get( aActiveSettable );
      if ( result == null ) return true;
      return result.booleanValue();
    }
  }

  public TLcyGroupDescriptor retrieveGroupDescriptor( ILcdAction aAction ) {
    synchronized ( fLock ) {
      return ( TLcyGroupDescriptor ) fGroupDescriptors.get( aAction );
    }
  }

  public TLcyGroupDescriptor retrieveGroupDescriptor( ILcyActiveSettable aActiveSettable ) {
    synchronized ( fLock ) {
      return ( TLcyGroupDescriptor ) fGroupDescriptors.get( aActiveSettable );
    }
  }

  public String retrieveHelpIDString( ILcdAction aAction ) {
    synchronized ( fLock ) {
      return ( String ) fHelpIDs.get( aAction );
    }
  }

  public String retrieveHelpIDString( ILcyActiveSettable aActiveSettable ) {
    synchronized ( fLock ) {
      return ( String ) fHelpIDs.get( aActiveSettable );
    }
  }

  public TLcyGroupDescriptor[] retrieveMenuGroupDescriptors( ILcdAction aAction ) {
    synchronized ( fLock ) {
      return ( TLcyGroupDescriptor[] ) fMenuGroupDescriptors.get( aAction );
    }
  }

  public TLcyGroupDescriptor[] retrieveMenuGroupDescriptors( ILcyActiveSettable aActiveSettable ) {
    synchronized ( fLock ) {
      return ( TLcyGroupDescriptor[] ) fMenuGroupDescriptors.get( aActiveSettable );
    }
  }

  public String[] retrieveMenus( ILcdAction aAction ) {
    synchronized ( fLock ) {
      return ( String[] ) fMenus.get( aAction );
    }
  }

  public String[] retrieveMenus( ILcyActiveSettable aActiveSettable ) {
    synchronized ( fLock ) {
      return ( String[] ) fMenus.get( aActiveSettable );
    }
  }

  public void setHelpIDString( ILcdAction aAction, String aID ) {
    synchronized ( fLock ) {
      if ( aID != null ) {
        fHelpIDs.put( aAction, aID );
      }
    }
  }

  public void setHelpIDString( ILcyActiveSettable aActiveSettable, String aID ) {
    synchronized ( fLock ) {
      if ( aID != null ) {
        fHelpIDs.put( aActiveSettable, aID );
      }
    }
  }

  private void fireActionAdded( ILcdAction aAction ) {
    fireActionBarChanged( new TLcyActionBarEvent( this, TLcyActionBarEvent.ACTION_ADDED, aAction ) );
  }

  private void fireActiveSettableAdded( ILcyActiveSettable aActiveSettable ) {
    fireActionBarChanged( new TLcyActionBarEvent( this, TLcyActionBarEvent.ACTIVE_SETTABLE_ADDED, aActiveSettable ) );
  }

  private void fireActionRemoved( ILcdAction aAction ) {
    fireActionBarChanged( new TLcyActionBarEvent( this, TLcyActionBarEvent.ACTION_REMOVED, aAction ) );
  }

  private void fireActiveSettableRemoved( ILcyActiveSettable aActiveSettable ) {
    fireActionBarChanged( new TLcyActionBarEvent( this, TLcyActionBarEvent.ACTIVE_SETTABLE_REMOVED, aActiveSettable ) );
  }

  private void fireActionBarChanged( TLcyActionBarEvent event ) {
    // listeners expect to be notified on the EDT.
    assert EventQueue.isDispatchThread();
    
    // Guaranteed to return a non-null array
    Object[] listeners = fActionBarListeners.getListenerList();
    // Process the listeners last to first, notifying
    // those that are interested in this event
    
    for ( int i = listeners.length - 2; i >= 0; i -= 2 ) {
      if ( listeners[i] == ILcyActionBarListener.class ) {
        ( ( ILcyActionBarListener ) listeners[i + 1] ).actionBarChanged( event );
      }
    }
  }

  /**
   * Add all the actions in this menu bar to the specified Eclipse menu. The actions and active
   * settables of the Lucy action bar are properly wrapped in Eclipse actions.
   *
   * @param aMenuManager The Eclipse menu in which to insert the actions of this menu bar.
   */
  public void addAllActions( final IMenuManager aMenuManager ) {
    synchronized ( fLock ) {
      Iterator items = fActionBarItems.iterator();
      while ( items.hasNext() ) {
        Object obj = items.next();
        Action action = ( Action ) fActionID.get( obj );
        if ( action != null )
          MenuMediator.insertContribution( aMenuManager, new ActionContributionItem( action ), ( ( TLcyGroupDescriptor ) fGroupDescriptors.get( obj ) ), ( ( String[] ) fMenus.get( obj ) ), ( ( TLcyGroupDescriptor[] ) fMenuGroupDescriptors.get( obj ) ) );
      }
    }
  }
}
