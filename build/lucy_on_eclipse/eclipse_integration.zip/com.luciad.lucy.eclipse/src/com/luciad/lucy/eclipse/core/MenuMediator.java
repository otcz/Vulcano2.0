/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.gui.ILcdAction;
import com.luciad.lucy.ILcyLucyEnv;
import com.luciad.lucy.eclipse.ui.*;
import com.luciad.lucy.eclipse.util.EventQueueUtil;
import com.luciad.lucy.gui.*;
import org.eclipse.jface.action.*;

import java.awt.*;
import java.io.*;
import java.net.*;
import java.text.MessageFormat;
import java.util.*;
import java.util.List;
import java.util.logging.*;

/**
 * This mediator keeps the state of an Eclipse menu and a Lucy action bar in sync. All actions of
 * the Lucy action bar are properly decorated to be able to put them in the Eclipse menu. It
 * makes sure that all operations happen on the correct thread.
 */
class MenuMediator implements ILcyActionBarListener {

  private static final Logger fLogger = Logger.getLogger(MenuMediator.class.getName());
  private static final String        ID_PREFIX      = "com.luciad.lucy.eclipse.menu.";
  private static final String        GROUP_ID_PREFIX      = "com.luciad.lucy.eclipse.group.";

  private static final MessageFormat MENU_ID_FORMAT = new MessageFormat( ID_PREFIX + "{0}" );

  private final IContributionManager fTargetContributionManager;

  // confined to Swing's EDT
  private final List                 fContributions = new ArrayList();
  
  // The actions in the Lucy action bar and Eclipse menu are visually orderer with this Comparator.
  private static final GroupDescriptorsComparator fComparator = initComparator();
  
  private static GroupDescriptorsComparator initComparator() {
    Properties properties = new Properties();
    try {
      URL url = ILcyLucyEnv.class.getClassLoader().getResource( "lucy/lucy.cfg" );
      InputStream is = url.openStream();
      properties.load( is );
      String order = properties.getProperty( "TLcyMain.menuBar.groupPriorities" );
      String[] groups = order.split( "," );
      for ( int i = 0; i < groups.length; i++ ) {
        groups[ i ] = groups[ i ].trim();
      }
      return new GroupDescriptorsComparator( groups );
    } catch ( MalformedURLException e ) {
      // This cannot happen, the URL above is well-formed.
      throw new RuntimeException( e );
    } catch ( IOException e ) {
      fLogger.log(Level.SEVERE, "The group order could not be read: " + e.getMessage());
      fLogger.log(Level.SEVERE, "Exception", e);
      return new GroupDescriptorsComparator( new String[0] );
    }
  }

  private MenuMediator( IContributionManager aTargetContributionManager, ILcyActionBar aSource ) {
    fTargetContributionManager = aTargetContributionManager;

    for ( int i = 0; i < aSource.getActionBarItemCount(); i++ ) {
      Object item = aSource.getActionBarItem( i );
      if ( item instanceof ILcdAction ) {
        insertLuciadLightspeedAction( aSource, ( ILcdAction ) item );
      }
      else if ( item instanceof ILcyActiveSettable ) {
        insertActiveSettable( aSource, ( ILcyActiveSettable ) item );
      }
    }
  }

  /**
   * <p>
   * Copies the actions and active settables already present in the source
   * ILcyActionBar to the target IContributionManager and installs the necessary
   * listeners to insert future actions and active settables added to the source
   * ILcyActionBar into the target IContributionManager.
   * </p>
   * 
   * @param aTarget
   *          The IContributionManager in which the actions of the source
   *          ILcyActionBar should be inserted.
   * @param aSource
   *          The ILcyActionBar whose actions should be inserted in the target
   *          IContributionManager.
   */
  public static void install( final IContributionManager aTarget, final ILcyActionBar aSource ) {
    assert EventQueue.isDispatchThread();
    MenuMediator mediator = new MenuMediator( aTarget, aSource );
    aSource.addActionBarListener( mediator );
  }

  public void actionBarChanged( TLcyActionBarEvent aEvent ) {
    int id = aEvent.getID();
    ILcyActionBar actionBar = aEvent.getActionBar();
    if ( id == TLcyActionBarEvent.ACTION_ADDED ) {
      ILcdAction action = aEvent.getAction();
      insertLuciadLightspeedAction( actionBar, action );
    }
    else if ( id == TLcyActionBarEvent.ACTIVE_SETTABLE_ADDED ) {
      ILcyActiveSettable active_settable = aEvent.getActiveSettable();
      insertActiveSettable( actionBar, active_settable );
    }
    else if ( id == TLcyActionBarEvent.ACTION_REMOVED ) {
      IContributionItem contribution = retrieveContribution( aEvent.getAction() );
      removeContribution( contribution );

    }
    else if ( id == TLcyActionBarEvent.ACTIVE_SETTABLE_REMOVED ) {
      IContributionItem contribution = retrieveContribution( aEvent.getActiveSettable() );
      removeContribution( contribution );
    }
    else throw new IllegalArgumentException( "The event has an invalid id" );

    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        fTargetContributionManager.update( true );
      }
    } );
  }

  private void removeContribution( final IContributionItem contribution ) {
    if ( contribution == null ) throw new IllegalArgumentException();
    fContributions.remove( contribution );

    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        removeContribution( fTargetContributionManager, contribution );
      }
    } );
  }

  private boolean removeContribution( final IContributionManager aMenuManager, IContributionItem aAction ) {
    IContributionItem[] items = aMenuManager.getItems();
    if ( items != null ) for ( int i = 0; i < items.length; i++ ) {
      if ( items[i] instanceof IMenuManager ) {
        if ( removeContribution( ( IMenuManager ) items[i], aAction ) ) {
          return true;
        }
      }
      else if ( items[i] == aAction ) {
        final IContributionItem item = items[i];
        aMenuManager.remove( item );
        return true;
      }
    }
    return false;
  }

  private void insertActiveSettable( ILcyActionBar aActionBar, ILcyActiveSettable aActiveSettable ) {
    assert EventQueue.isDispatchThread();

    String[] menus = aActionBar.retrieveMenus( aActiveSettable );
    TLcyGroupDescriptor[] menuGroups = aActionBar.retrieveMenuGroupDescriptors( aActiveSettable );
    TLcyGroupDescriptor group = aActionBar.retrieveGroupDescriptor( aActiveSettable );

    ActionContributionItem contribution = new ActionContributionItem( new LucyActiveSettableAdapter( aActiveSettable ) );

    insertContributionInTarget( contribution, group, menus, menuGroups );
  }

  private void insertLuciadLightspeedAction( ILcyActionBar actionBar, ILcdAction action ) {
    assert EventQueue.isDispatchThread();

    String[] menus = actionBar.retrieveMenus( action );
    TLcyGroupDescriptor[] menuGroups = actionBar.retrieveMenuGroupDescriptors( action );
    TLcyGroupDescriptor group = actionBar.retrieveGroupDescriptor( action );

    ActionContributionItem contribution = new ActionContributionItem( new LucyActionAdapter( action ) );

    insertContributionInTarget( contribution, group, menus, menuGroups );
  }

  private void insertContributionInTarget( final IContributionItem aContribution, final TLcyGroupDescriptor aGroup, final String[] aMenus, final TLcyGroupDescriptor[] aMenuGroups ) {
    fContributions.add( aContribution );
    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        insertContribution( fTargetContributionManager, aContribution, aGroup, aMenus, aMenuGroups );
      }
    } );
  }

  public static void insertContribution( final IContributionManager aMenumanager, final IContributionItem aContribution, final TLcyGroupDescriptor aGroupDescriptor, final String[] aMenus, final TLcyGroupDescriptor[] aMenuGroupDescriptors ) {
    IContributionManager manager = createSubMenus( aMenumanager, aMenus, aMenuGroupDescriptors );
    if ( manager != null ) {
      insertContribution( manager, aContribution, aGroupDescriptor );
    }
  }

  private static void insertContribution( IContributionManager aMenuManager, IContributionItem aContribution, TLcyGroupDescriptor aGroupDescriptor ) {
    TLcyGroupDescriptor group = aGroupDescriptor == null ? TLcyGroupDescriptor.DEFAULT : aGroupDescriptor;
    insertOrderedContribution( aMenuManager, aContribution, group, true );
  }

  private static IContributionManager createSubMenus( IContributionManager aMenuManager, String[] aMenus, TLcyGroupDescriptor[] aMenuGroupDescriptors ) {

    IContributionManager current = aMenuManager;
    if ( aMenus != null ) {
      for ( int i = 0; i < aMenus.length; i++ ) {
        String menu_id = MENU_ID_FORMAT.format( new Object[]{aMenus[i]} );
        IContributionItem item = current.find( menu_id );
        if ( item == null ) {
          item = new MenuManager( aMenus[i], menu_id );

          TLcyGroupDescriptor group;
          if ( aMenuGroupDescriptors != null &&
               aMenuGroupDescriptors[i] != null &&
               aMenuGroupDescriptors[i].getUID() != null ) {
            group = aMenuGroupDescriptors[i];
          }
          else {
            group = TLcyGroupDescriptor.DEFAULT;
          }

          //for the first level we do not want separators.
          insertOrderedContribution( current, item, group, i != 0 );
        }
        
        if ( item instanceof IContributionManager ) {
          current = ( IContributionManager ) item;
        }
        else {
          throw new IllegalStateException("A contribution action that is not a menu was added with a menu ID");
        }
      }
    }
    return current;
  }

  private static void insertOrderedContribution( IContributionManager aTarget, IContributionItem aContributionItem, TLcyGroupDescriptor aGroupDescriptor, boolean aShouldUseSeparator ) {
    try {
      aTarget.appendToGroup( formatUIDString( aGroupDescriptor ), aContributionItem );
    } catch ( IllegalArgumentException e ) {
      // The specified group did not exist, insert it in the correct location
      
      IContributionItem[] all_items = aTarget.getItems();
      List group_uids = new ArrayList();

      // collect all the present group UID's. collect all their original group names.
      for ( int item_index = 0; item_index < all_items.length; item_index++ ) {
        IContributionItem contributionItem = all_items[item_index];
        if ( contributionItem.getId() != null && 
             contributionItem.getId().startsWith( GROUP_ID_PREFIX ) ) {
          group_uids.add( contributionItem.getId().substring( GROUP_ID_PREFIX.length() ) );
        }
      }

      String before_uid = null;
      for ( Iterator it = group_uids.iterator(); it.hasNext(); ) {
        String uid = ( String ) it.next();
        if ( fComparator.compare( aGroupDescriptor.getUID(), uid ) < 0 ) {
          before_uid = uid;
          break;
        }
      }

      if ( aShouldUseSeparator ) {
        Separator separator = new Separator( formatUIDString( aGroupDescriptor ) );
        addGroup( aTarget, before_uid, separator );
      }
      else {
        GroupMarker group = new GroupMarker( formatUIDString( aGroupDescriptor ) );
        addGroup( aTarget, before_uid, group );
      }

      aTarget.appendToGroup( formatUIDString( aGroupDescriptor ), aContributionItem );
    }
  }

  private static void addGroup( IContributionManager aContributionManager, String aBeforeUID, AbstractGroupMarker aGroup ) {
    if ( aBeforeUID == null ) {
      aContributionManager.add( aGroup );
    }
    else {
      aContributionManager.insertBefore( formatUIDString( aBeforeUID ), aGroup );
    }
  }

  private static String formatUIDString( TLcyGroupDescriptor aGroupDescriptor ) {
    return formatUIDString( aGroupDescriptor.getUID() );
  }

  private static String formatUIDString( String aGroupUID ) {
    return GROUP_ID_PREFIX + aGroupUID;
  }

  private IContributionItem retrieveContribution( Object aAction ) {
    assert EventQueue.isDispatchThread();

    for ( Iterator it = fContributions.iterator(); it.hasNext(); ) {
      ActionContributionItem contribution = ( ActionContributionItem ) it.next();
      IAction eclipse_action = contribution.getAction();
      if ( eclipse_action instanceof LucyActionAdapter ) {
        LucyActionAdapter action = ( LucyActionAdapter ) eclipse_action;
        if ( action.getAction() == aAction ) {
          return contribution;
        }
      }
      else if ( eclipse_action instanceof LucyActiveSettableAdapter ) {
        LucyActiveSettableAdapter as = ( LucyActiveSettableAdapter ) eclipse_action;
        if ( as.getActiveSettable() == aAction ) {
          return contribution;
        }
      }
      else throw new IllegalStateException( "The contributions list contains invalid entries" );
    }
    return null;
  }

}
