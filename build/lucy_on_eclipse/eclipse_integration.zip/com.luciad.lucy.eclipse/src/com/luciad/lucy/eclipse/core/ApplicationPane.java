/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.lucy.ILcyLucyEnv;
import com.luciad.lucy.eclipse.ui.LucyViewPart;
import com.luciad.lucy.gui.*;
import org.eclipse.core.runtime.IStatus;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Implementation of {@link ILcyApplicationPane}. This class has also a
 * corresponding {@link LucyViewPart} component with the same first ID and
 * secondary ID. The {@link LucyViewPart} is the part visible in Eclipse
 * framework. Changes applied to this object has to be applied also on the
 * corresponding {@link LucyViewPart} object.
 */
class ApplicationPane extends JPanel implements ILcyApplicationPane {

  private static final Object ID_CLIENT_PROPERTY_KEY = new Object();

  private String                  fAppTitle;
  private boolean                 fDisposable        = true;
  private boolean                 fAppVisible        = false;
  private Properties              fProperties        = new Properties();

  private boolean                 fDisposed          = false;

  private final ILcyLucyEnv       fLucyEnv;
  
  //confined to AWT thread
  private final CompositeListener fCompositeListener = new CompositeListener(); 

  /**
   * Creates a new {@link ApplicationPane} with the given application pane
   * owner and the given first and second ID. If the second ID is null, no
   * second ID is used.
   * 
   * @param lucyEnv
   * @param aOwner
   */
  public ApplicationPane( ILcyLucyEnv lucyEnv, ILcyApplicationPaneOwner aOwner ) {
    assertEDT();

    fLucyEnv = lucyEnv;

    if ( aOwner != null ) {
      addApplicationPaneListener( new ApplicationPaneOwnerAdapter( aOwner ) );
    }
  }

  public void addApplicationPaneListener( ApplicationPaneListener aOwner ) {
    fCompositeListener.addApplicationPaneListener( aOwner );
  }

  public void removeApplicationPaneListener( ApplicationPaneListener aOwner ) {
    fCompositeListener.removeApplicationPaneListener( aOwner );
  }

  /**
   * Brings the corresponding {@link LucyViewPart} to the front.
   */
  public void bringAppToFront() {
    assertEDT();
    fCompositeListener.requestsToFront( this );
  }

  public boolean canPackApp() {
    assertEDT();
    return false;
  }

  /**
   * Disposes this application pane.
   */
  public void disposeApp() {
    assertEDT();

    if ( !fDisposed ) {
      fDisposed = true;
      fLucyEnv.getUserInterfaceManager().getApplicationPaneManager().applicationPaneRemoved( this );
      if ( fCompositeListener != null ) {
        fCompositeListener.applicationPaneDisposing( new EventObject( this ) );
      }
    }
    else {
      System.out.println( "App pane [" + getAppTitle() + "] was already disposed" );
    }
  }

  /**
   * Returns the content pane of this application pane.
   */
  public Container getAppContentPane() {
    return this;
  }

  public Dimension getAppSize() {
    return getSize();
  }

  public String getAppTitle() {
    assertEDT();
    return fAppTitle;
  }

  public boolean isAppVisible() {
    assertEDT();
    return fAppVisible;
  }

  public boolean isDisposable() {
    assertEDT();
    return fDisposable;
  }

  public void packApp() {
    assertEDT();
  }

  public void setAppEnabled( boolean flag ) {
    assertEDT();
    if ( flag != isEnabled() ) {
      setEnabled( flag );
      firePropertyChange( "appEnabled", !flag, flag );
    }
  }

  public void setAppSize( Dimension dimension ) {
    assertEDT();
  }

  public void setAppTitle( String aAppTitle ) {
    assertEDT();

    String old = fAppTitle;
    fAppTitle = aAppTitle;
    firePropertyChange( "appTitle", old, fAppTitle );
  }

  public void setAppVisible( boolean visible ) {
    assertEDT();
    if ( visible != fAppVisible ) {
      fAppVisible = visible;
      firePropertyChange( "appVisible", !fAppVisible, fAppVisible );
    }
  }

  public void setDisposable( boolean disposable ) {
    assertEDT();
    if ( disposable != fDisposable ) {
      fDisposable = disposable;
      firePropertyChange( "disposable", !fDisposable, fDisposable );
    }
  }

  public void setResizable( boolean flag ) {
    assertEDT();
    // the implementation is never resizable.
  }

  public Object getValue( String aKey ) {
    assertEDT();
    return fProperties.getProperty( aKey );
  }

  public void putValue( String aKey, Object aObject ) {
    assertEDT();
    Object oldValue = fProperties.getProperty( aKey );
    fProperties.put( aKey, aObject );
    firePropertyChange( aKey, oldValue, aObject );
  }

  public void setSecondaryID( String aSecondaryID ) {
    putClientProperty( ID_CLIENT_PROPERTY_KEY, aSecondaryID );
  }

  public String getSecondaryID() {
    return ( String ) getClientProperty( ID_CLIENT_PROPERTY_KEY );
  }

  private void assertEDT() {
    if ( !EventQueue.isDispatchThread() ) {
      LucyPlugin.log( IStatus.ERROR, "Method called from wrong thread!", new Exception() );
    }
  }

  private static class CompositeListener implements ApplicationPaneListener {
    private List fApplicationPaneOwners = new ArrayList();

    public void applicationPaneDisposing( EventObject aEvent ) {
      for ( Iterator it = fApplicationPaneOwners.iterator(); it.hasNext(); ) {
        ILcyApplicationPaneOwner owner = ( ILcyApplicationPaneOwner ) it.next();
        owner.applicationPaneDisposing( aEvent );
      }
    }

    public void requestsToFront( ApplicationPane aApplicationPane ) {
      for ( Iterator it = fApplicationPaneOwners.iterator(); it.hasNext(); ) {
        ApplicationPaneListener listener = ( ApplicationPaneListener ) it.next();
        listener.requestsToFront( aApplicationPane );
      }
    }

    public void addApplicationPaneListener( ApplicationPaneListener aListener ) {
      fApplicationPaneOwners.add( aListener );
    }

    public void removeApplicationPaneListener( ApplicationPaneListener aListener ) {
      fApplicationPaneOwners.remove( aListener );
    }
  }

  public static interface ApplicationPaneListener extends ILcyApplicationPaneOwner {
    void requestsToFront( ApplicationPane aApplicationPane );
  }

  private static class ApplicationPaneOwnerAdapter implements ApplicationPaneListener {
    private final ILcyApplicationPaneOwner fAdaptee;

    public ApplicationPaneOwnerAdapter( ILcyApplicationPaneOwner aAdaptee ) {
      super();
      fAdaptee = aAdaptee;
    }

    public void applicationPaneDisposing( EventObject aEvent ) {
      fAdaptee.applicationPaneDisposing( aEvent );
    }

    public void requestsToFront( ApplicationPane arg0 ) {
      // not interested, empty implementation
    }
  }
}
