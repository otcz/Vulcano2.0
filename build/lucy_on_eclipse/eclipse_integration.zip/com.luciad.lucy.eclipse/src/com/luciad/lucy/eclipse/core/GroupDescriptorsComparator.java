/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import java.util.*;
import java.util.logging.*;

/**
 * Orders group descriptors according to the given array.
 */
class GroupDescriptorsComparator implements Comparator {

  private static final Logger fLogger = Logger.getLogger(GroupDescriptorsComparator.class.getName());
  private HashMap fGroupPriorities = new HashMap();

  public GroupDescriptorsComparator( String[] aGroupDescriptorOrdering ) {
    if ( aGroupDescriptorOrdering != null ) {
      // put data in hashtable, for faster lookups
      for ( int index = 0; index < aGroupDescriptorOrdering.length; index++ ) {
        String group = aGroupDescriptorOrdering[index];
        fGroupPriorities.put( group, new Integer( index ) );
      }
    }
  }

  public int compare( Object aGroup1, Object aGroup2 ) {
    int group1_index = retrieveTargetIndexOf( ( String ) aGroup1 );
    int group2_index = retrieveTargetIndexOf( ( String ) aGroup2 );
    if ( group1_index < group2_index ) {
      return -1;
    }
    else if ( group1_index == group2_index ) {
      return 0;
    }
    else return 1;
  }

  private int retrieveTargetIndexOf( String aGroupDescriptor ) {
    Object value = fGroupPriorities.get( aGroupDescriptor );
    if ( value != null ) {
      return ( ( Integer ) value ).intValue();
    }
    else {
      fLogger.log(Level.FINEST, "Don't know where to put unknown group[" + aGroupDescriptor + "], will put it after known groups.", this);
      return Integer.MAX_VALUE;
    }
  }
}
