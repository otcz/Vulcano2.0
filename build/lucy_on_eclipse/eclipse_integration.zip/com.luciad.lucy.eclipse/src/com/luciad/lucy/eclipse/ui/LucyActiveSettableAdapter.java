/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import com.luciad.gui.*;
import com.luciad.gui.swing.*;
import com.luciad.lucy.eclipse.util.EventQueueUtil;
import com.luciad.lucy.gui.ILcyActiveSettable;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.*;

/**
 * This adapter wraps a Lucy active settable and presents it as an Eclipse action. It makes sure
 * all operations on the Lucy active settable are performed on the correct thread.
 * 
 * @see LucyActionAdapter
 */
public class LucyActiveSettableAdapter extends Action {

  private ILcyActiveSettable fActiveSettable;
  private boolean            fMediatorDisabled = false; // confined to AWT thread

  public LucyActiveSettableAdapter( ILcyActiveSettable aActiveSettable ) {
    this( aActiveSettable, null );
  }

  public LucyActiveSettableAdapter( ILcyActiveSettable aActiveSettable, String aID ) {
    super( ( String ) aActiveSettable.getValue( ILcyActiveSettable.NAME ), Action.AS_CHECK_BOX );
    setId( aID );
    fActiveSettable = aActiveSettable;

    setChecked( fActiveSettable.isActive() );
    setEnabled( fActiveSettable.isEnabled() );
    setToolTipText( ( String ) fActiveSettable.getValue( ILcdAction.SHORT_DESCRIPTION ) );
    setDescription( ( String ) fActiveSettable.getValue( ILcdAction.LONG_DESCRIPTION ) );
    ILcdIcon icon = ( ILcdIcon ) fActiveSettable.getValue( ILcdAction.SMALL_ICON );
    if ( icon != null ) {
      setImageDescriptor( ImageDescriptor.createFromImageData( ActionMediator.convertIconToImage( new TLcdSWIcon( icon ) ) ) );
    }

    new TLcdSWAction( new ActiveSettableWrapper( fActiveSettable ) ).addPropertyChangeListener( new ActionMediator( this ) );

    fActiveSettable.addPropertyChangeListener( new PropertyChangeListener() {
      public void propertyChange( PropertyChangeEvent aEvt ) {
        if ( "active".equals( aEvt.getPropertyName() ) ) {
          if ( !fMediatorDisabled ) {
            EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
              public void run() {
                setChecked( fActiveSettable.isActive() );
              }
            } );
          }
        }
      }
    } );
  }

  public ILcyActiveSettable getActiveSettable() {
    return fActiveSettable;
  }

  public void run() {
    Runnable runnable = new Runnable() {
      public void run() {
        fMediatorDisabled = true;
        fActiveSettable.setActive( isChecked() );
        fMediatorDisabled = false;
      }
    };
    if ( SwingUtilities.isEventDispatchThread() ) {
      runnable.run();
    }
    else SwingUtilities.invokeLater( runnable );
  }

  private static class ActiveSettableWrapper implements ILcdAction {
    private final ILcyActiveSettable    fActiveSettable;
    private final PropertyChangeSupport fPropertyChangeSupport = new PropertyChangeSupport( this );

    public ActiveSettableWrapper( ILcyActiveSettable aActiveSettable ) {
      super();
      fActiveSettable = aActiveSettable;
      fActiveSettable.addPropertyChangeListener( new Redirector() );
    }

    public Object getValue( String aKey ) {
      return fActiveSettable.getValue( aKey );
    }

    public boolean isEnabled() {
      return fActiveSettable.isEnabled();
    }

    public void putValue( String aKey, Object aValue ) {
      fActiveSettable.putValue( aKey, aValue );
    }

    public void setEnabled( boolean aEnabled ) {
      fActiveSettable.setEnabled( aEnabled );
    }

    public void addPropertyChangeListener( PropertyChangeListener aListener ) {
      fPropertyChangeSupport.addPropertyChangeListener( aListener );
    }

    public void removePropertyChangeListener( PropertyChangeListener aListener ) {
      fPropertyChangeSupport.removePropertyChangeListener( aListener );
    }

    public void actionPerformed( ActionEvent aE ) {
      throw new UnsupportedOperationException( "This method should not be called" );
    }

    private class Redirector implements PropertyChangeListener {
      public void propertyChange( PropertyChangeEvent aEvt ) {
        fPropertyChangeSupport.firePropertyChange( aEvt.getPropertyName(), aEvt.getOldValue(), aEvt.getNewValue() );
      }
    }
  }
}
