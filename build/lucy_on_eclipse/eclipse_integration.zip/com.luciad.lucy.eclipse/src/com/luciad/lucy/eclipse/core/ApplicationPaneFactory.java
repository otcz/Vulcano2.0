/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.lucy.ILcyLucyEnv;
import com.luciad.lucy.gui.*;
import com.luciad.lucy.workspace.*;

import java.io.*;
import java.util.Properties;

/**
 * This implementation creates ILcyApplicationPane instances that are shown in a IViewPart. To show
 * the application panes in an Eclipse view part, it installs a mediator on the application panes
 * and their corresponding view parts to make sure that all operations on the application pane are
 * reflected on the view part and vice versa.
 */
public class ApplicationPaneFactory implements ILcyApplicationPaneFactory {

  public static final String VERTICAL_PANE_2_ID = "com.luciad.lucy.VerticalPane2View";
  public static final String VERTICAL_PANE_ID   = "com.luciad.lucy.VerticalPaneView";
  public static final String HORIZONTAL_PANE_ID = "com.luciad.lucy.HorizontalPaneView";
  public static final String MAP_PANE_ID        = "com.luciad.lucy.MapPaneView";

  static final String[] ALL_IDS = {
      MAP_PANE_ID,
      HORIZONTAL_PANE_ID,
      VERTICAL_PANE_ID,
      VERTICAL_PANE_2_ID
  };

  private static int getLucyViewPartIDCount() {
    return ApplicationPaneFactory.ALL_IDS.length;
  }

  private static String getLucyViewPartID( int aIndex ) {
    return ApplicationPaneFactory.ALL_IDS[ aIndex ];
  }

  private ILcyLucyEnv fLucyEnv;
  private int         fCounter = 0;

  public ApplicationPaneFactory() {
  }

  public void setLucyEnv( ILcyLucyEnv aLucyEnv ) {
    fLucyEnv = aLucyEnv;
  }

  public ILcyApplicationPane createApplicationPane( ILcyApplicationPaneOwner aOwner ) {
    return createApplicationPane( ILcyApplicationPaneFactory.MAP_PANE, aOwner );
  }

  public ILcyApplicationPane createApplicationPane( int aLocationIndex, ILcyApplicationPaneOwner aOwner ) {
    ApplicationPane pane = new ApplicationPane( fLucyEnv, aOwner );

    fLucyEnv.getUserInterfaceManager().getApplicationPaneManager().applicationPaneAdded( pane );
    applicationPaneCreated( pane, aLocationIndex );

    return pane;
  }

  public void applicationPaneCreated( ApplicationPane aApplicationPane, int aLocationIndex ) {
    if ( !fLucyEnv.getWorkspaceManager().isDecodingWorkspace() ) {
      handleApplicationPane( aApplicationPane, aLocationIndex );
    }
    else {
      // the delayed listener listens for the end of the workspace decoding, and makes sure
      // that the application pane is given a secondary ID when it was not restored from the
      // workspace but merely created as a result of some other event.
      DelayedInitializer initializer = new DelayedInitializer( aApplicationPane, aLocationIndex );
      fLucyEnv.getWorkspaceManager().addWorkspaceManagerListener( initializer );
    }
  }

  private void handleApplicationPane( ApplicationPane aApplicationPane, int aLocationIndex ) {
    if ( retrieveSecondaryID( aApplicationPane ) != null ) {
      // this application pane was already processed and given an secondary ID
      return;
    }
    String aSecondaryID = generateSecondaryID( aLocationIndex );
    handleSecondaryID( aApplicationPane, aSecondaryID );
  }

  /**
   * Generates a secondary ID. This ID contains a part that specifies the initial location, and a
   * part to make it unique.
   *
   * @param aLocationIndex The initial location index of the application pane for which this ID is
   *                       generated.
   *
   * @return A unique secondary ID.
   */
  private String generateSecondaryID( int aLocationIndex ) {
    String secondary_id_part;
    if ( aLocationIndex < getLucyViewPartIDCount() ) {
      secondary_id_part = getLucyViewPartID( aLocationIndex );
    }
    else {
      secondary_id_part = getLucyViewPartID( getLucyViewPartIDCount() - 1 );
    }
    while ( findApplicationPaneForID( secondary_id_part + "-" + fCounter ) != null ) {
      fCounter++;
    }

    return secondary_id_part + "-" + fCounter;
  }

  /**
   * This class waits for the workspace decoding to end before actually inserting the application
   * pane in an Eclipse view. This way the workspace decoding can first get a chance to restore the
   * mapping between application panes and Eclipse views.
   */
  private class DelayedInitializer implements ILcyWorkspaceManagerListener {
    private final ApplicationPane fApplicationPane;
    private final int             fLocationIndex;

    public DelayedInitializer( ApplicationPane aApplicationPane, int aLocationIndex ) {
      super();
      fApplicationPane = aApplicationPane;
      fLocationIndex = aLocationIndex;
    }

    public void workspaceStatusChanged( TLcyWorkspaceManagerEvent aEvent ) {
      if ( TLcyWorkspaceManagerEvent.WORKSPACE_DECODING_ENDED == aEvent.getID() ) {
        handleApplicationPane( fApplicationPane, fLocationIndex );
      }
    }
  }

  /**
   * Actually inserting the application pane in an Eclipse view is done by the
   * ApplicationPaneViewMediator.
   *
   * @param aApplicationPane The application pane to show in an eclipse view
   * @param aSecondaryID     The secondary ID to be used for showing the application pane in an
   *                         eclipse view.
   */
  private void handleSecondaryID( ApplicationPane aApplicationPane, String aSecondaryID ) {
    setSecondaryID( aApplicationPane, aSecondaryID );
    ApplicationPaneViewMediator.install( aApplicationPane, aSecondaryID, fLucyEnv );
  }

  private ApplicationPane findApplicationPaneForID( String aID ) {
    TLcyApplicationPaneManager manager = fLucyEnv.getUserInterfaceManager().getApplicationPaneManager();
    for ( int i = 0; i < manager.getApplicationPaneCount(); i++ ) {
      ApplicationPane pane = ( ApplicationPane ) manager.getApplicationPane( i );
      String id = retrieveSecondaryID( pane );
      if ( aID.equals( id ) ) {
        return pane;
      }
    }
    return null;
  }

  private void setSecondaryID( ApplicationPane aApplicationPane, String aSecondaryID ) {
    aApplicationPane.setSecondaryID( aSecondaryID );
  }

  public String getSecondaryID( ILcyApplicationPane aApplicationPane ) {
    return retrieveSecondaryID( ( ApplicationPane ) aApplicationPane );
  }

  private static String retrieveSecondaryID( ApplicationPane aApplicationPane ) {
    return aApplicationPane.getSecondaryID();
  }

  public ALcyWorkspaceCodecDelegate createCodecDelegate( String aUID, String aPrefix ) {
    return new WorkspaceCodecDelegate( aUID, aPrefix );
  }

  /**
   * This workspace codec delegate stores the mapping between open Eclipse views (by their primary
   * and secondary ID) and the open Lucy application panes. It restores this mapping when decoding
   * the workspace.
   */
  private class WorkspaceCodecDelegate extends ALcyWorkspaceCodecDelegate {

    private static final String SECONDARY_ID = ".secondaryID";
    private static final String PANE = ".pane";
    private static final String INFIX = "applicationPane.";
    private static final String APPLICATION_PANE_COUNT = "applicationPaneCount";

    private final String fUID;
    private final String fPrefix;

    public WorkspaceCodecDelegate( String aUID, String aPrefix ) {
      super();
      fUID = aUID;
      fPrefix = aPrefix;
    }

    public String getUID() {
      return fUID;
    }

    public void encode( ALcyWorkspaceCodec aWSCodec, OutputStream aOut ) throws IOException {
      Properties properties = new Properties();

      TLcyApplicationPaneManager manager = fLucyEnv.getUserInterfaceManager().getApplicationPaneManager();
      int count = manager.getApplicationPaneCount();
      properties.setProperty( fPrefix + APPLICATION_PANE_COUNT, Integer.toString( count ) );

      for ( int i = 0; i < count; i++ ) {
        ApplicationPane pane = ( ApplicationPane ) manager.getApplicationPane( i );
        if ( aWSCodec.canEncodeReference( pane ) ) {
          String pane_ref = aWSCodec.encodeReference( pane );
          String secondaryID = retrieveSecondaryID( pane );
          properties.setProperty( fPrefix + INFIX + i + PANE, pane_ref );
          properties.setProperty( fPrefix + INFIX + i + SECONDARY_ID, secondaryID );
        }
      }

      properties.store( aOut, "" );
    }

    public void decode( ALcyWorkspaceCodec aWSCodec, InputStream aIn ) throws IOException {
      Properties properties = new Properties();
      properties.load( aIn );

      int count;
      try {
        count = Integer.parseInt( properties.getProperty( fPrefix + APPLICATION_PANE_COUNT ) );
      } catch ( NumberFormatException e ) {
        count = 0;
      }

      //we only need to restore which application pane belongs in which Eclipse view. The
      //Eclipse workspace itself will have restored the location and status of the Eclipse 
      //views.
      for ( int i = 0; i < count; i++ ) {
        String pane_ref = properties.getProperty( fPrefix + INFIX + i + PANE );
        String id = properties.getProperty( fPrefix + INFIX + i + SECONDARY_ID );

        ApplicationPane pane = ( ApplicationPane ) aWSCodec.decodeReference( pane_ref );

        if ( pane != null ) {
          assert findApplicationPaneForID( id ) == null;
          handleSecondaryID( pane, id );
        }
      }
    }
  }
}
