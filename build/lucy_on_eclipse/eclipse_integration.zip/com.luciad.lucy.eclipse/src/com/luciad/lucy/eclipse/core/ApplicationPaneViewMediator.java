/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.lucy.ILcyLucyEnv;
import com.luciad.lucy.eclipse.ui.LucyViewPart;
import com.luciad.lucy.eclipse.util.*;
import com.luciad.lucy.gui.*;
import com.luciad.lucy.map.*;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.ui.*;

import javax.swing.*;
import java.awt.*;
import java.beans.*;
import java.util.EventObject;

/**
 * This mediator ensures that all operations that happen on an application pane are propagated
 * to the Eclipse view and vice versa. For instance, when the application pane is made visible, it
 * will make sure that an Eclipse view is opened to show the application pane. When the application 
 * pane is disposed, it will also close the Eclipse view.
 */
class ApplicationPaneViewMediator implements PropertyChangeListener, ApplicationPane.ApplicationPaneListener {

  private final String fSecondaryID;
  private final ILcyLucyEnv fLucyEnv;
  private boolean fDisposingIsoHiding = true;
  
  public ApplicationPaneViewMediator( String aSecondaryID, ILcyLucyEnv aLucyEnv ) {
    super();
    fSecondaryID = aSecondaryID;
    fLucyEnv = aLucyEnv;
  }

  private synchronized void setDisposingIsoHiding( boolean disposingIsoHiding ) {
    fDisposingIsoHiding = disposingIsoHiding;
  }

  private synchronized boolean isDisposingIsoHiding() {
    return fDisposingIsoHiding;
  }

  public void propertyChange( PropertyChangeEvent aEvt ) {
    ApplicationPane app_pane = ( ApplicationPane ) aEvt.getSource();

    if ( "appVisible".equals( aEvt.getPropertyName() ) ) {
      Boolean visible = ( Boolean ) aEvt.getNewValue();
      if ( visible.booleanValue() ) {
        showApplicationPaneInViewPart( app_pane );
      }
      else {
        //hide the Eclipse view without disposing the application pane
        hideViewPartOfApplicationPane( false );
      }
    }
    
    else if ("appTitle".equals( aEvt.getPropertyName() )){
      setViewPartTitle( ( String ) aEvt.getNewValue() );
    }
  }

  public void applicationPaneDisposing( EventObject aEvent ) {
    //hide the Eclipse view while also disposing the application pane.
    hideViewPartOfApplicationPane( true );
  }

  /**
   * When the application pane requests to be brought to the front, the Eclipse view in which the
   * application pane is shown will be brought to the front.
   *
   * @param aApplicationPane The application pane that should be brought to the front.
   */
  public void requestsToFront( ApplicationPane aApplicationPane ) {
    assertEDT();
    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        if ( PlatformUI.getWorkbench() != null &&
             PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null &&
             PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null ) {
          IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
          IViewReference partRef = page.findViewReference( LucyViewPart.VIEW_ID, fSecondaryID );
          if ( partRef != null ) {
            IWorkbenchPart part = partRef.getPart( false );
            if ( part != null ) page.bringToTop( part );
          }
        }
      }
    } );
  }

  /**
   * Sets the specified title on the Eclipse view in which the application pane is shown.
   *
   * @param aTitle The title to show on the Eclipse view.
   */
  private void setViewPartTitle( final String aTitle ) {
    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        if ( PlatformUI.getWorkbench() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null ) {
          IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
          IViewReference ref = page.findViewReference( LucyViewPart.VIEW_ID, fSecondaryID );
          if ( ref == null ) {
            //there is a bug in some Eclipse releases where the ID must be the primary ID
            //_and_ the secondary ID joined by a colon.
            //https://bugs.eclipse.org/bugs/show_bug.cgi?id=401709
            ref = page.findViewReference( LucyViewPart.VIEW_ID + ":" + fSecondaryID, fSecondaryID );
          }
          if ( ref != null ) {
            LucyViewPart part = ( LucyViewPart ) ref.getView( false );
            part.setApplicationPaneTitle( aTitle );

          }
        }
      }
    } );
  }

  private void assertEDT() {
    if ( !EventQueue.isDispatchThread() ) {
      LucyPlugin.log( IStatus.ERROR, "Method called on the wrong thread!", new Exception() );
    }
  }

  private void refreshActionBars( final LucyViewPart lucy_view ) {
    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        lucy_view.getViewSite().getActionBars().updateActionBars();
      }
    } );
  }

  private void showApplicationPaneInViewPart( final ApplicationPane aApplicationPane ) {
    assertEDT();
    final String appTitle = aApplicationPane.getAppTitle();

    //create the Eclipse view part on the SWT thread. Install all necessary listeners to 
    //apply the changes in the Eclipse view to the application pane as well.
    EventQueueUtil.EventQueueRunnable on_swt = new EventQueueUtil.EventQueueRunnable() {
      public Object run( Object aArg ) {
        if ( PlatformUI.getWorkbench() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null ) {
          try {
            final IWorkbenchPage page = 
              PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
            final LucyViewPart lucy_view = ( LucyViewPart ) page.showView( 
                LucyViewPart.VIEW_ID, fSecondaryID, IWorkbenchPage.VIEW_ACTIVATE );
            lucy_view.setApplicationPaneTitle( appTitle );

            page.addPartListener( new PartAdapter2() {
              public void partClosed( IWorkbenchPartReference aPartRef ) {
                if ( lucy_view == aPartRef.getPart( false ) ) {
                  //if the Eclipse view was closed in response to the application pane's request
                  //to be hidden, the application pane should not be disposed.
                  //See #hideViewPartOfApplicationPane
                  if ( isDisposingIsoHiding() ) {
                    EventQueueUtil.invokeAndWait( new Runnable() {
                      public void run() {
                        aApplicationPane.disposeApp();
                      }
                    } );
                  }
                  aPartRef.getPage().removePartListener( this );
                }
              }
            } );

            return lucy_view;
          } catch ( PartInitException e ) {
            throw new RuntimeException( e );
          }
        }
        else {
          throw new RuntimeException( "The active page could not be found" );
        }
      }
    };

    // This callback is executed on the AWT thread with the Eclipse view, the result of the
    // runnable (which was executed on the SWT thread).
    EventQueueUtil.EventQueueRunnable callback = new EventQueueUtil.EventQueueRunnable() {
      public Object run( Object aArg ) {
        final LucyViewPart lucy_view = ( LucyViewPart ) aArg;
        IWorkbenchPage page = lucy_view.getViewSite().getPage();

        lucy_view.addToAWTContentPanel( aApplicationPane );

        //make sure that when the application pane contains an ILcyMapComponent and when the 
        //Eclipse view of the application pane is given focus, the map component is set as the
        //active map component.
        TLcyCombinedMapManager mapManager = fLucyEnv.getCombinedMapManager();
        ActiveMapMediator.install( page, mapManager, lucy_view, aApplicationPane );

        //If the application pane contains an ILcyMapComponent, show the menu bar of that map
        //component in the menu of the Eclipse view.
        final ILcyActionBar action_bar = findActionBar( aApplicationPane );
        if ( action_bar != null ) {
          final IMenuManager menuManager = lucy_view.getViewSite().getActionBars().getMenuManager();
          MenuMediator.install( menuManager, action_bar );

          refreshActionBars( lucy_view );

          action_bar.addActionBarListener( new ILcyActionBarListener() {
            public void actionBarChanged( TLcyActionBarEvent aEvent ) {
              refreshActionBars( lucy_view );
            }
          } );
        }

        return null;
      }

    };

    EventQueueUtil.onSWT( on_swt, callback );
  }

  /**
   * If the content of the application pane contains an * ILcyMapComponent, this method returns its
   * menu bar. Otherwise it simply returns null.
   *
   * This method should be called from AWT's Event Dispatch Thread.
   *
   * @param aApplicationPane The application pane that might contain the map component.
   *
   * @return The menu bar of the map component if it found one, <code>null</code> otherwise.
   */
  private ILcyActionBar findActionBar( ILcyApplicationPane aApplicationPane ) {
    assertEDT();
    final TLcyMapManager mapManager = fLucyEnv.getMapManager();
    for ( int i = 0; i < mapManager.getMapComponentCount(); i++ ) {
      final ILcyMapComponent map = mapManager.getMapComponent( i );
      if ( SwingUtilities.isDescendingFrom( map.getComponent(), aApplicationPane.getAppContentPane() ) ) {
        return map.getMenuBar();
      }
    }
    return null;
  }


  /**
   * Hides the Eclipse view of the application pane for which this mediator is active.
   *
   * @param aDisposeIsoHide <code>true</code> if the application pane should also be disposed
   *                        <code>false</code> if the application pane only needs to be hidden, not
   *                        disposed.
   */
  private void hideViewPartOfApplicationPane( final boolean aDisposeIsoHide ) {
    EventQueueUtil.asyncExecOrNoopWhenDisposed( new Runnable() {
      public void run() {
        if ( PlatformUI.getWorkbench() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null ) {
          IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
          IViewReference ref = page.findViewReference( LucyViewPart.VIEW_ID, fSecondaryID );
          if ( ref != null ) {
            setDisposingIsoHiding( aDisposeIsoHide );
            page.hideView( ref );
          }
        }
      }
    } );
  }

  /**
   * Creates the mediator that will apply all changes in the application pane to the Eclipse view as
   * well, and vice versa. The Eclipse view is created by the specified secondary ID.
   *
   * @param aApplicationPane The application pane to show in an Eclipse view.
   * @param aSecondID        The secondary ID to use when an Eclipse view should be generated.
   * @param aLucyEnv         The Lucy backend for which the application pane is shown.
   */
  public static void install( ApplicationPane aApplicationPane, String aSecondID, ILcyLucyEnv aLucyEnv ) {
    ApplicationPaneViewMediator mediator = new ApplicationPaneViewMediator( aSecondID, aLucyEnv );
    if ( aApplicationPane.isAppVisible() ) {
      mediator.showApplicationPaneInViewPart( aApplicationPane );
    }
    aApplicationPane.addPropertyChangeListener( mediator );
    aApplicationPane.addApplicationPaneListener( mediator );
  }
}
