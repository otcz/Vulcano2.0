/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.ui;

import com.luciad.gui.ALcdAction;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.ActionEvent;
import java.beans.*;
import java.lang.ref.WeakReference;

/**
 * This action finds the first component in the Swing hierarchy tree that has a
 * <code>TransferHandler</code> and an action associated with the action command
 * in the action map, and performs that action.
 */
abstract class TransferAction extends ALcdAction {
  
  public static TransferAction createCopyAction(){
    return new CopyAction();
  }
  
  public static TransferAction createCutAction(){
    return new CutAction();
  }
  
  public static TransferAction createPasteAction(){
    return new PasteAction();
  }

  private JComponent        fFocusOwner = null;
  private String            fActionCommand;
  private EventListenerList fListeners  = new EventListenerList();

  public TransferAction( String aActionCommand ) {
    fActionCommand = aActionCommand;
    KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    manager.addPropertyChangeListener( "permanentFocusOwner", new MyPropertyChangeListener( this ) );
    updateState();
  }

  public void actionPerformed( ActionEvent e ) {
    JComponent component = findApplicableComponent( fFocusOwner, fActionCommand );
    if ( component == null ) return;

    Action action = component.getActionMap().get( fActionCommand );
    if ( action != null ) {
      action.actionPerformed( new ActionEvent( component, ActionEvent.ACTION_PERFORMED, null ) );
      fireChangeEvent();
    }
  }

  /**
   * Finds the first component in the Swing component hierarchy above
   * fFocusOwner that has a TransferHandler and has a correct action in the
   * action map.
   * 
   * @return The first such component.
   */
  protected static JComponent findApplicableComponent( JComponent aComponent, String aActionCommand ) {
    JComponent current_component = aComponent;
    while ( current_component != null && ( current_component.getTransferHandler() == null || current_component.getActionMap().get( aActionCommand ) == null ) ) {

      Container parent = current_component.getParent();
      if ( parent instanceof JComponent ) current_component = ( JComponent ) parent;
      else current_component = null;
    }
    return current_component;
  }

  public JComponent getFocusOwner() {
    return fFocusOwner;
  }

  public void setFocusOwner( JComponent aFocusOwner ) {
    fFocusOwner = aFocusOwner;
  }

  public String getActionCommand() {
    return fActionCommand;
  }

  public void setActionCommand( String aActionCommand ) {
    fActionCommand = aActionCommand;
  }

  public void addChangeListener( ChangeListener aChangeListener ) {
    fListeners.add( ChangeListener.class, aChangeListener );
  }

  public void removeChangeListener( ChangeListener aChangeListener ) {
    fListeners.remove( ChangeListener.class, aChangeListener );
  }

  private void fireChangeEvent() {
    // Guaranteed to return a non-null array
    Object[] listeners = fListeners.getListenerList();
    // Process the listeners last to first, notifying
    // those that are interested in this event
    ChangeEvent change_event = null;
    for ( int i = listeners.length - 2; i >= 0; i -= 2 ) {
      if ( listeners[i] == ChangeListener.class ) {
        // Lazily create the event:
        if ( change_event == null ) change_event = new ChangeEvent( this );
        ( ( ChangeListener ) listeners[i + 1] ).stateChanged( change_event );
      }
    }
  }

  public abstract void updateState();

  private static class MyPropertyChangeListener implements PropertyChangeListener {
    private final WeakReference fAction;

    public MyPropertyChangeListener( TransferAction aAction ) {
      fAction = new WeakReference( aAction );
    }

    private TransferAction getAction() {
      Object referent = fAction.get();
      if ( referent == null ) {
        KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        manager.removePropertyChangeListener( "permanentFocusOwner", this );
      }
      return ( TransferAction ) referent;
    }

    public void propertyChange( PropertyChangeEvent e ) {
      TransferAction action = getAction();
      if ( action == null ) return; // the action was GC'ed
      Object new_value = e.getNewValue();
      if ( new_value instanceof JComponent ) action.setFocusOwner( ( JComponent ) new_value );
      else action.setFocusOwner( null );

      action.updateState();
    }
  }
  
  private static class CopyAction extends TransferAction {
    public CopyAction() {
      super( ( String ) TransferHandler.getCopyAction().getValue( Action.NAME ) );
    }

    public void updateState() {
      boolean disabled = findApplicableComponent( getFocusOwner(), getActionCommand() ) == null;
      setEnabled( !disabled );
    }
  }

  private static class CutAction extends TransferAction {
    public CutAction() {
      super( ( String ) TransferHandler.getCutAction().getValue( Action.NAME ) );
    }

    public void updateState() {
      boolean disabled = findApplicableComponent( getFocusOwner(), getActionCommand() ) == null;
      setEnabled( !disabled );
    }
  }

  private static class PasteAction extends TransferAction {
    public PasteAction() {
      super( ( String ) TransferHandler.getPasteAction().getValue( Action.NAME ) );
    }

    public void updateState() {
      try {
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        Transferable contents = clipboard.getContents( this );
        JComponent component = findApplicableComponent( getFocusOwner(), getActionCommand() );
        boolean enabled =
            component != null && 
            component.getTransferHandler().canImport( getFocusOwner(), contents.getTransferDataFlavors() ) &&
            findApplicableComponent( getFocusOwner(), getActionCommand() ) != null;
        
        setEnabled( enabled );
      } catch ( Exception e ) {
        setEnabled( true ); //when an error occurs, we assume it will be solved by the time the action is invoked.
      }
    }
  }
}
