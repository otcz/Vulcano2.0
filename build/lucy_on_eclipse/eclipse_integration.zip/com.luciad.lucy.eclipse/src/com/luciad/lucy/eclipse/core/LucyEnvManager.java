/*
 *
 * Copyright (c) 1999-2018 Luciad NV All Rights Reserved.
 *
 * Luciad grants you ("Licensee") a non-exclusive, royalty free, license to use,
 * modify and redistribute this software in source and binary code form,
 * provided that i) this copyright notice and license appear on all copies of
 * the software; and ii) Licensee does not utilize the software in a manner
 * which is disparaging to Luciad.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING ANY
 * IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NON-INFRINGEMENT, ARE HEREBY EXCLUDED. LUCIAD AND ITS LICENSORS SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING
 * OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL LUCIAD OR ITS
 * LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE USE OF
 * OR INABILITY TO USE SOFTWARE, EVEN IF LUCIAD HAS BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 */

package com.luciad.lucy.eclipse.core;

import com.luciad.lucy.*;
import com.luciad.lucy.util.TLcyVetoException;
import org.eclipse.ui.*;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.util.logging.*;

public class LucyEnvManager {

  private static final Logger fLogger = Logger.getLogger(LucyEnvManager.class.getName());

  private static LucyEnvManager sManager;

  private ILcyLucyEnv                  fLucyEnv;
  private ApplicationPaneFactory       fApplicationPaneFactory;

  private LucyEnvManager() {

    TLcyLucyEnvFactory factory = new TLcyLucyEnvFactory();

    fApplicationPaneFactory = new ApplicationPaneFactory( );
    fLucyEnv = factory.createLucyEnv( fApplicationPaneFactory, MenuBar.getDefault(), true );
    fApplicationPaneFactory.setLucyEnv( fLucyEnv );
    
    //add the workspace codec delegate to store the information of the application panes and their
    //corresponding Eclipse views.
    fLucyEnv.getWorkspaceManager().addWorkspaceCodecDelegate( fApplicationPaneFactory.createCodecDelegate( "com.luciad.lucy.eclipse.EclipseIntegrationFrontend", "EclipseIntegrationFrontend." ) );
    
    PlatformUI.getWorkbench().addWorkbenchListener( new IWorkbenchListener() {
      public void postShutdown( IWorkbench aWorkbench ) {
        try {
          fLucyEnv.setLucyEnvState( ILcyLucyEnv.STATE_CLOSED );
          fLucyEnv.setLucyEnvState( ILcyLucyEnv.STATE_DISPOSING );
          fLucyEnv.setLucyEnvState( ILcyLucyEnv.STATE_DISPOSED );
        } catch ( TLcyVetoException vetoed ) {
          // somebody veto'ed the closing, at this point there's nothing we can
          // do about that
        }
      }

      public boolean preShutdown( IWorkbench aWorkbench, boolean aForced ) {
        try {
          fLucyEnv.setLucyEnvState( ILcyLucyEnv.STATE_CLOSING );
          return true;
        } catch ( TLcyVetoException vetoed ) {
          return false;
        }
      }
    } );
    
    WorkspaceSaver.initializeWorkspaceSaving();
    
    Runnable runnable = new Runnable() {
      public void run() {
        // Indicate to possible lucy env listeners that initializing the lucy
        // env has started.
        try {
          fLucyEnv.setLucyEnvState( ILcyLucyEnv.STATE_INITIALIZING );
    
          // we use an OSGI url here because otherwise TLcyXMLAddOnLoader will
          // try to resolve the sourcename against its own classloader, which
          // is confined to its own plugin.
          loadAddOns( fLucyEnv, getClass().getClassLoader().getResource( "addons_eclipse.xml" ).toString() );
          fLucyEnv.setLucyEnvState( ILcyLucyEnv.STATE_INITIALIZED );
    
          //restore the workspace from the Eclipse workspace.
          WorkspaceSaver.restoreWorkspace( LucyEnvManager.this );
        } catch ( TLcyVetoException e ) {
          e.printStackTrace();
        }
      }
    };
    if ( EventQueue.isDispatchThread() ) runnable.run();
    else try {
      EventQueue.invokeAndWait( runnable );
    } catch ( InterruptedException e ) {
      e.printStackTrace();
    } catch ( InvocationTargetException e ) {
      e.printStackTrace();
    }
  }

  public ApplicationPaneFactory getApplicationPaneFactory() {
    return fApplicationPaneFactory;
  }

  public ILcyLucyEnv getLucyEnv() {
    return fLucyEnv;
  }

  /**
   * Returns the central manager. If this is the first time this method is called, the manager and
   * its Lucy backend will be initialized.
   *
   * @return The central LucyEnvManager with an initialized Lucy backend.
   */
  public synchronized static LucyEnvManager getManager() {
    //lazily load the manager and its Lucy backend.
    if ( sManager == null ) {
      sManager = new LucyEnvManager();
    }
    return sManager;
  }

  /**
   * Loads the addons from the specified addons XML file.
   *
   * @param aLucyEnv    The Lucy backend in which to plug the addons specified in the addons file.
   * @param aAddonsFile The addons XML file containing the addons to load.
   */
  private void loadAddOns( ILcyLucyEnv aLucyEnv, String aAddonsFile ) {
    TLcyXMLAddOnLoader xml_loader = new TLcyXMLAddOnLoader( aLucyEnv, aAddonsFile );

    // Listener that displays which addon is currently being loaded.
    ILcyAddOnContainerListener addon_listener = new ILcyAddOnContainerListener() {
      public void addOnContainerChanged( TLcyAddOnContainerEvent aEvent ) {
        if ( aEvent.getID() == TLcyAddOnContainerEvent.ADDON_ADDING ) {
          fLogger.log(Level.FINEST, "Loading " + aEvent.getAddOn().getDisplayName(), LucyEnvManager.this);
        }
      }
    };
    aLucyEnv.addAddOnContainerListener( addon_listener );
    xml_loader.loadAddOns();
    aLucyEnv.removeAddOnContainerListener( addon_listener );
  }
}
